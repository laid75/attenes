
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attendance;

class AttendanceController extends Controller
{
    public function index()
    {
        return view('attendance.index', ['attendances' => Attendance::all()]);
    }

    public function markAttendance(Request $request)
    {
        $request->validate([
            'student_name' => 'required',
            'status' => 'required|in:present,absent'
        ]);

        Attendance::create([
            'student_name' => $request->student_name,
            'status' => $request->status,
        ]);

        return redirect('/attendance')->with('success', 'Attendance marked successfully!');
    }
}
