
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance</title>
</head>
<body>
    <h1>Attendance List</h1>
    
    @if(session('success'))
        <p style="color: green;">{{ session('success') }}</p>
    @endif

    <form action="/attendance/mark" method="POST">
        @csrf
        <label>Student Name:</label>
        <input type="text" name="student_name" required>
        <label>Status:</label>
        <select name="status">
            <option value="present">Present</option>
            <option value="absent">Absent</option>
        </select>
        <button type="submit">Mark Attendance</button>
    </form>

    <h2>Recorded Attendance</h2>
    <ul>
        @foreach($attendances as $attendance)
            <li>{{ $attendance->student_name }} - {{ $attendance->status }}</li>
        @endforeach
    </ul>

    <a href="/">Back to Home</a>
</body>
</html>
